"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var express = require("express");
var app = express();
var port = process.env.PORT || 4005;
var runningMessage = 'Server is running on port ' + port;
app.get('/', function (req, res) {
    res.send(runningMessage);
});
var server = app.listen(port, function () {
    console.log(runningMessage);
});
module.exports = server;
