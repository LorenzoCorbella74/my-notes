import { InitCapsPipe } from './init-caps.pipe';

describe('InitCapsPipe', () => {
  it('create an instance', () => {
    const pipe = new InitCapsPipe();
    expect(pipe).toBeTruthy();
  });
});
