import { Directive } from '@angular/core';

@Directive({
  selector: '[appSearchBox]'
})
export class SearchBoxDirective {

  constructor() { }

}
