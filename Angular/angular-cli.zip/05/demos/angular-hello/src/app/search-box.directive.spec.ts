import { SearchBoxDirective } from './search-box.directive';

describe('SearchBoxDirective', () => {
  it('should create an instance', () => {
    const directive = new SearchBoxDirective();
    expect(directive).toBeTruthy();
  });
});
