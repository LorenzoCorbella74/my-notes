import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogginginComponent } from './loggingin/loggingin.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [LogginginComponent]
})
export class LoginModule { }
