import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loggingin',
  templateUrl: './loggingin.component.html',
  styleUrls: ['./loggingin.component.css']
})
export class LogginginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
